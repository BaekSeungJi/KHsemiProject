package control;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ReviewControl extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req,resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		doProcess(req,resp);
	}

	
	public void doProcess(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		req.setCharacterEncoding("utf-8");
		resp.setContentType("text/html; charset=UTF-8");
		
		String command = req.getParameter("command");
		
		if(command.equals("writeReviewGo")) {
			
			int seq = Integer.parseInt(req.getParameter("seq"));
			String hotelname = req.getParameter("hotelname");
			String checkin = req.getParameter("checkin");
			String checkout = req.getParameter("checkout");
			
			System.out.println("writeReview  seq:"+seq);
			System.out.println("writeReview  hotelname:"+hotelname);
			System.out.println("writeReview  checkin:"+checkin);
			System.out.println("writeReview  checkout:"+checkout);
			
		
			
			req.setAttribute("seq", seq);
			req.setAttribute("hotelname", hotelname);
			req.setAttribute("checkin", checkin);
			req.setAttribute("checkout", checkout);
			
			// 리뷰작성페이지로 이동		
			// dispatch("???", req, resp);
		}
		
	}
	
	public void dispatch(String urls,HttpServletRequest req, HttpServletResponse resp)  throws ServletException, IOException{
	RequestDispatcher dispatch = req.getRequestDispatcher(urls);
	dispatch.forward(req, resp);
		}
}
