package model.calendar;

public interface icalendarManager {

	
}
