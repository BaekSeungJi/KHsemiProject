package model.review;

public interface iReviewManager {

}
