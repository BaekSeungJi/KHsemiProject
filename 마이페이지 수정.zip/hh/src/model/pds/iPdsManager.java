package model.pds;

public interface iPdsManager {

}
